//
//  HttpCallBack.swift
//  SidebarMenu
//
//  Created by Xiao Li on 5/26/16.
//  Copyright © 2016 AppCoda. All rights reserved.
//

import Foundation

// we create a call back funtion to retrive response from server
class HttpCallBack: NSObject {
    
    /*
     * @parameter: user means username
     * @parameter: passwd means password
     * @parameter: successfulHandler, a callback process, to get response from ascyn connection
     *
     */
    func send(user:String , passwd:String, successHandler: (response: String) -> NSString){
        
        // set server address is http://localhost:8080/IOSServer/connectedTest
        let url = NSURL(string: "http://localhost:8080/IOSServer/connectedTest")!
        
        // combine the user name and password with space and store to NSString variable post
        // and encoding with NSASCIIString format
        var post:NSString = user + " " + passwd
        var postData:NSData = post.dataUsingEncoding(NSASCIIStringEncoding)!
        var postLength:String = String(postData.length)
        
        /*
         * @parameter: URL address
         * @parameter: cachePolicy
         * @Parameter: timeout Interval
         * @Parameter: HTTPBody: carry message
         * @Parameter: HTTPMethod: POST
         * @Parameter: setvalue: to set the post length
         * @parameter: addValue: to add format for data
         */
        let urlRequest = NSMutableURLRequest(
            URL: url,
            cachePolicy: .ReloadIgnoringLocalAndRemoteCacheData,
            timeoutInterval: 10.0 * 1000)
        
        urlRequest.HTTPBody = postData
        urlRequest.HTTPMethod = "POST"
        urlRequest.setValue(postLength, forHTTPHeaderField: "Content-Length")
        urlRequest.addValue("application/json", forHTTPHeaderField: "Accept")
        
        // start connection task with ascyn way
        let task = NSURLSession.sharedSession().dataTaskWithRequest(urlRequest)
        {
            (data, response, error) -> Void in
            
            if error != nil
            {
                print("error=\(error)")
                
            } else
            {
                successHandler(response: NSString(data: data!, encoding: NSUTF8StringEncoding)! as String!);
            }
            
        }
        
        task.resume()
    }
    
    
    
    func sendRegister(user:String , passwd:String, email:String, successHandler: (response: String) -> NSString){
        
        // set server address is http://localhost:8080/IOSServer/connectedTest
        let url = NSURL(string: "http://localhost:8080/IOSServer/connectedTest")!
        
        // combine the user name and password with space and store to NSString variable post
        // and encoding with NSASCIIString format
        var post:NSString = user + " " + passwd + " " + email
        var postData:NSData = post.dataUsingEncoding(NSASCIIStringEncoding)!
        var postLength:String = String(postData.length)
        
        /*
         * @parameter: URL address
         * @parameter: cachePolicy
         * @Parameter: timeout Interval
         * @Parameter: HTTPBody: carry message
         * @Parameter: HTTPMethod: POST
         * @Parameter: setvalue: to set the post length
         * @parameter: addValue: to add format for data
         */
        let urlRequest = NSMutableURLRequest(
            URL: url,
            cachePolicy: .ReloadIgnoringLocalAndRemoteCacheData,
            timeoutInterval: 10.0 * 1000)
        
        urlRequest.HTTPBody = postData
        urlRequest.HTTPMethod = "POST"
        urlRequest.setValue(postLength, forHTTPHeaderField: "Content-Length")
        urlRequest.addValue("application/json", forHTTPHeaderField: "Accept")
        
        // start connection task with ascyn way
        let task = NSURLSession.sharedSession().dataTaskWithRequest(urlRequest)
        {
            (data, response, error) -> Void in
            
            if error != nil
            {
                print("error=\(error)")
                
            } else
            {
                successHandler(response: NSString(data: data!, encoding: NSUTF8StringEncoding)! as String!);
            }
            
        }
        
        task.resume()
    }

}

