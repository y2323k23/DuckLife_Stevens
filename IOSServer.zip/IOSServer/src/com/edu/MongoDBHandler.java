package com.edu;
import static com.mongodb.client.model.Projections.excludeId;
import static com.mongodb.client.model.Projections.fields;
import static com.mongodb.client.model.Projections.include;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteConcern;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.util.JSON;
import static com.mongodb.client.model.Projections.*;

public class MongoDBHandler {
	private MongoClient mongoclient;
	private MongoDatabase db;
	
	public MongoDBHandler(){
		try {
			mongoclient = new MongoClient();
			db = mongoclient.getDatabase("stevensLiftInfoDB");
			System.out.println("Connect mongodb successfully");
		} catch(Exception e) {
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}
	
	public boolean judge(String usr, String pa) {
		MongoCollection<org.bson.Document> collections = db.getCollection("loginInfo");		       
		for(Document doc : collections.find().projection(fields(include("username","password"), excludeId()))){
			DBObject dbo = (DBObject)JSON.parse(doc.toJson());
			if(dbo.get("username") != null && dbo.get("password") != null && dbo.get("username").equals(usr) && dbo.get("password").equals(pa)) {
				System.out.println(dbo.get("username").toString());
				return true;
			}
		 }
			return false;		
	}
	
	public String insert(String usr, String pa, String email) {
		try {
			MongoCollection<org.bson.Document> collections = db.getCollection("loginInfo");	
			mongoclient.setWriteConcern(WriteConcern.JOURNALED);
			org.bson.Document doc = new org.bson.Document();
			doc.append("username", usr)
			.append("password", pa)
			.append("stevensEmail", email);
			collections.insertOne(doc);
			
		} catch(Exception e) {
			System.out.println(e.getClass() + " " + e.getMessage());
			return "false";
		}
		return "true";
		
	}
	
	public void close() {
		mongoclient.close();
	}
	
}

