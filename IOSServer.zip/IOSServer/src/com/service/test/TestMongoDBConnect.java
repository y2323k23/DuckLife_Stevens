package com.service.test;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import static com.mongodb.client.model.Projections.*;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.util.JSON;

import netscape.javascript.JSObject;

import org.json.*;

public class TestMongoDBConnect {
	public static void main(String[] args) {
		try {
		MongoClient mongoclient = new MongoClient();
		MongoDatabase db = mongoclient.getDatabase("test");
		System.out.println("Connect successfully");
		System.out.println(db.getName());
		MongoCollection collections = db.getCollection("test");
		System.out.println(collections.count()); // [datas, names, system.indexes, users]
		
		Document doc = new Document("name", "MongoDB")
	               .append("type", "database")
	               .append("count", 1)
	               .append("info", new Document("x", 203).append("y", 102));
        // Note that the insert method can take either an array or a document.
        
        collections.insertOne(doc);
        List<Document> documents = new ArrayList<Document>();
        for (int i = 0; i < 100; i++) { 
            documents.add(new Document("i", i));
        }
        collections.insertMany(documents);
        System.out.println(collections.count());
        
       // Document myDoc = collections.find().first();
        //System.out.println(myDoc.toJson());
        MongoCursor<Document> cursor = collections.find().projection(fields(include("name"), excludeId())).iterator();
        while (cursor.hasNext()) {
        	JSObject js = (JSObject)JSON.parse(cursor.next().toJson());
            System.out.println(js);
        }
		} catch(Exception e) {
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
		}
		
	}
	
	

}
