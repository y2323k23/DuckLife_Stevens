package com.service.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.net.Socket;

public class Service extends Thread{
	private Socket socket;
	
	public Service(Socket socket) {
		this.socket = socket;
	}
	
	public void run() {
		try {
			socket.getOutputStream().write("already connect!\r\n".getBytes());
			//System.out.println("ttttttt");
			BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			BufferedWriter output = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			String line = input.toString();
			line = input.readLine();
			while(line != null) {
				if(line.equals("quit"))
					return;
				output.write("send back: " + line + " \n");
				System.out.println("send back " + line);
				output.flush();
				line = input.readLine();
			}
			input.close();
			output.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			try {
				socket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
