package com.service.test;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Entry {
	public static void main(String[] args) {
		try {
			ServerSocket server = new ServerSocket(8080);
			for(;;) {
				Socket client = server.accept();
				System.out.println("Connect with : " + client.getInetAddress());
				Service service = new Service(client);
				service.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
