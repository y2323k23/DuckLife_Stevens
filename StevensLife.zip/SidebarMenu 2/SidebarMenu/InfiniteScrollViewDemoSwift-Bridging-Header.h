//
//  InfiniteScrollViewDemoSwift-Bridging-Header.h
//  StevensLife
//
//  Created by Xiao Li on 5/31/16.
//  Copyright © 2016 AppCoda. All rights reserved.
//

#ifndef InfiniteScrollViewDemoSwift_Bridging_Header_h
#define InfiniteScrollViewDemoSwift_Bridging_Header_h

#import "UIScrollView+InfiniteScroll.h"

#endif /* InfiniteScrollViewDemoSwift_Bridging_Header_h */
