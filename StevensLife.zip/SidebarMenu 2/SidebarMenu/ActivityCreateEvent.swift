//
//  ActivityCreateEvent.swift
//  StevensLife
//
//  Created by 杨仁青 on 16/6/8.
//  Copyright © 2016年 AppCoda. All rights reserved.
//

import UIKit

//
//  ActivityDetailController.swift
//  StevensLife
//
//  Created by Xiao Li on 6/6/16.
//  Copyright © 2016 AppCoda. All rights reserved.
//

import UIKit

class ActivityCreateEvent: UIViewController ,UIImagePickerControllerDelegate,UINavigationControllerDelegate, UITextViewDelegate {
    
    @IBOutlet weak var navigationBarItem: UINavigationBar!
    
    @IBOutlet weak var inputTextView: UITextView!
    
    var story: ActivityInfo?
    var activityImage: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = story?.Text
        inputTextView!.layer.borderWidth = 1
        inputTextView.text = "Please edit"
        self.inputTextView.textColor = UIColor.lightGrayColor()
    }
    
    override func viewDidLayoutSubviews() {
        //activityImage.frame = CGRectMake(0, 0, self.view.frame.size.width, 128)
        self.navigationBarItem.frame = CGRectMake(0, 0, self.view.frame.size.width,60)
        self.inputTextView.frame = CGRectMake(4, 62, self.view.frame.size.width-8,250)
        self.inputTextView.layer.cornerRadius = 8.0
        //self.inputText.layer.masksToBounds = true
        self.inputTextView.layer.borderWidth = 0.5
    }
    
    @IBAction func back(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    @IBAction func registerButtonAction(sender: AnyObject) {
        
        if inputTextView.text == nil {
            
        }
        
        if activityImage == nil {
            
        }
        
        let httpRequest = HttpCallBack()
        httpRequest.sendPic(activityImage!,content: inputTextView.text!,id: "1")
        let alertView = UIAlertController(title: "Alert", message: "register successful! \n Please sign in!", preferredStyle: UIAlertControllerStyle.Alert)
        let OKAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default){ (action) in
            // pop here
            self.dismissViewControllerAnimated(true, completion: nil);
        }
        alertView.addAction(OKAction)
        self.presentViewController(alertView, animated: true, completion: nil)
    }
    
    @IBAction func addPic(sender: AnyObject) {
        //send image to server
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .PhotoLibrary
        imagePickerController.delegate = self
        presentViewController(imagePickerController, animated: true, completion: nil)
        
    }
    @IBAction func backToActivity(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
        
    }
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        let selectedImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        activityImage = selectedImage
        //imageView.image = selectedImage
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func textViewDidBeginEditing(inputTextView: UITextView) {
        if self.inputTextView.textColor == UIColor.lightGrayColor() {
            self.inputTextView.text = nil
            self.inputTextView.textColor = UIColor.blackColor()
        }
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        if self.inputTextView.text.isEmpty {
            self.inputTextView.text = "Please edit"
            self.inputTextView.textColor = UIColor.lightGrayColor()
        }
    }
    
    
    
}
