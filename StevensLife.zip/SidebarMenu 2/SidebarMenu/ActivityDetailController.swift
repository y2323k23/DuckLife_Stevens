//
//  ActivityDetailController.swift
//  StevensLife
//
//  Created by Xiao Li on 6/6/16.
//  Copyright © 2016 AppCoda. All rights reserved.
//

import UIKit

class ActivityDetailController: UIViewController{

    var story: ActivityInfo?
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = story?.Text
        print(story)
        let data = NSData(contentsOfURL: story!.URL!)
        imageView.image = UIImage(data: data!)

    }
    
    @IBAction func back(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
}
