//
//  POSTBoardTableViewController.swift
//  StevensLife
//
//  Created by Xiao Li on 6/22/16.
//  Copyright © 2016 AppCoda. All rights reserved.
//

import UIKit

class POSTBoardTableViewController: UITableViewController {
    
    @IBOutlet var menuButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if self.revealViewController() != nil {
            menuButton.target = self.revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.tableView.rowHeight = 240
        }
    }
}
