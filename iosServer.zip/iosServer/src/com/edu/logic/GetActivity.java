package com.edu.logic;

import static com.mongodb.client.model.Projections.excludeId;
import static com.mongodb.client.model.Projections.fields;
import static com.mongodb.client.model.Projections.include;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.codec.binary.Base64;
import org.apache.tomcat.util.http.fileupload.ByteArrayOutputStream;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.bson.Document;
import org.json.JSONObject;

import com.mongodb.DBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.util.JSON;

import sun.misc.IOUtils;

/**
 * Servlet implementation class GetActivity
 */
@WebServlet("/GetActivity")
public class GetActivity extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetActivity() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("The cilent has connected with server");
		int length = request.getContentLength();
        byte[] input = new byte[length];
        ServletInputStream sin = request.getInputStream();
        int c, count = 0 ;
        while ((c = sin.read(input, count, input.length-count)) != -1) {
            count +=c;
        }
        sin.close();
//        File file = new File("/Users/rq/desktop/water-drop-after-convert.jpg");
//        FileInputStream imageInFile = new FileInputStream(file);
//        byte imageData[] = new byte[(int)file.length()];
//        imageInFile.read(imageData);
//
//        // Converting Image byte array into Base64 String
//        String imageDataString = encodeImage(imageData);
//
//        
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        BufferedImage img = ImageIO.read(new File("/Users/rq/desktop/water-drop-after-convert.jpg"));
//        ImageIO.write(img, "JPG", bos);
//        byte[] bytes = bos.toByteArray();
//        String base64bytes = encodeImage(bytes);
        MongoDBHandler handler = new MongoDBHandler();
        System.out.println(handler.getActivity());
        OutputStreamWriter out = new OutputStreamWriter(response.getOutputStream());
        out.write(handler.getActivity());
        out.flush();
        out.close();
	}
	public static String encodeImage(byte[] imageByteArray) {
		return Base64.encodeBase64URLSafeString(imageByteArray);
	}

	public static byte[] decodeImage(String imageDataString) {
		return Base64.decodeBase64(imageDataString);
	}
}
