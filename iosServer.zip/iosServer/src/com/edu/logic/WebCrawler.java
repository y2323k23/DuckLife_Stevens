package com.edu.logic;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.mongodb.util.JSON;

public class WebCrawler {
	private static final int MAX_PAGES_TO_SEARCH = 10;
	private Set<String> pagesVisited = new HashSet<String>();
	private List<String> pagesToVisit = new LinkedList<String>();
	MongoDBHandler mongo = new MongoDBHandler();
	
	public void crawler(String _url, Set<String> visitedUrl, int depth) {
		if (visitedUrl.contains(_url) || depth > 10) {
			return;
		}
		 try {
			 	visitedUrl.add(_url);
	            Document _doc = Jsoup.connect(_url).userAgent("Mozilla").execute().parse() ;
				Elements articles = _doc.getElementsByTag("article");
				Elements pageUrl = _doc.getElementsByTag("ul").tagName("pager").eq(2);
				Elements links = new Elements();
				if(pageUrl.size() > 0)
					links = pageUrl.get(0).getElementsByTag("li");
				System.out.println(links.size() + "   ");
				for(Element elem : articles) {
					//Element detailEle = elem.g;
					Elements title = elem.select("a");
					Elements details = elem.getElementsByTag("div");
					if(details != null && details.size() != 0) {
						String date = elem.getElementsByTag("time").text();
						StringBuilder sourceStr = new StringBuilder();
						String url = "http://www.stevens.edu" + elem.getElementsByTag("a").attr("href");
						String picUrl = elem.getElementsByTag("source").attr("srcset");
						for(Element e : details) {
							//if(e.getElementById("p") != null)
								sourceStr.append(e.getElementsByTag("p").text()).append(" ");
						}
						if(sourceStr != null && sourceStr.length() != 0) { 
							//for test && title.text().equals("Stevens Institute of Technology Announces Class of 2016 Commencement Speakers")
							/*System.out.println("Title::: " + title.text());		
							System.out.println("date is::: " + date);
							System.out.println("content::: " + sourceStr.toString());
							System.out.println("url::: " + url);
							System.out.println("pic Url is ::: " + picUrl);
							System.out.println(); */
							mongo.insertNews(title.text(), date, sourceStr.toString(), url, picUrl);
						}
					}
				}
				
				for(Element link : links) {
					//System.out.println("new_url is : " + link);
					String new_url = "http://www.stevens.edu" + link.getElementsByTag("a").attr("href");
					//System.out.println("new_url is : " + new_url);
					if(!visitedUrl.contains(new_url)) {
						crawler(new_url, visitedUrl, depth + 1);
					}
				}
				
	        } catch (MalformedURLException e) {
	            //nothing
	        } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
	}
	
	public static void main(String[] args) {
		WebCrawler craw = new WebCrawler();
	    Set<String> visitedUrls = new HashSet<>();
	    String url = "https://www.stevens.edu/news/?page=1#news_list";
	    craw.crawler(url, visitedUrls, 0);
	}
	
}
