package com.edu.logic;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteConcern;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.util.JSON;
import static com.mongodb.client.model.Projections.*;

public class MongoDBHandler {
	private MongoClient mongoclient;
	private MongoDatabase db;
	private final IndexOptions options = new IndexOptions();
	public MongoDBHandler(){
		try {
			mongoclient = new MongoClient();
			db = mongoclient.getDatabase("stevensLiftInfoDB");
			System.out.println("Connect mongodb successfully");
		} catch(Exception e) {
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}
	
	public boolean judge(String usr, String pa) {
		MongoCollection<org.bson.Document> collections = db.getCollection("loginInfo");	
		for(Document doc : collections.find().projection(fields(include("username","password"), excludeId()))){
			DBObject dbo = (DBObject)JSON.parse(doc.toJson());
			if(dbo.get("username") != null && dbo.get("password") != null && dbo.get("username").equals(usr) && dbo.get("password").equals(pa)) {
				System.out.println(dbo.get("username").toString());
				return true;
			}
		 }
			return false;		
	}
	
	public String insert(String usr, String pa, String email) {
		try {
			MongoCollection<org.bson.Document> collections = db.getCollection("loginInfo");	
			mongoclient.setWriteConcern(WriteConcern.JOURNALED);
			org.bson.Document doc = new org.bson.Document();
			doc.append("username", usr)
			.append("password", pa)
			.append("stevensEmail", email);
			collections.insertOne(doc);
			
		} catch(Exception e) {
			System.out.println(e.getClass() + " " + e.getMessage());
			return "false";
		}
		return "true";
		
	}
	
	public void close() {
		mongoclient.close();
	}
	
	
	/*Insert Activity
	 * usr: the username of people who post this activity
	 * actName: the activity name which the user post
	 * actID: Use to record the activity, it is unique
	 * image: the image shows on the activity
	 * content: the content of the activity
	 * capacity: the large number which can register on the activity
	 * registerNum: current register number of this activity
	 * comment: the comment of this activity*/
	public String insertActivity(String usr, String actName, String actID, String image, 
			String content, int capacity, int registerNum, List<org.bson.Document> comment) {
		try {
			MongoCollection<org.bson.Document> collections = db.getCollection("ActivityTableInfo");	
			mongoclient.setWriteConcern(WriteConcern.JOURNALED);
			org.bson.Document doc = new org.bson.Document();
			
			//use unique index to check unique username and emailaddress
			options.unique(true);
			collections.createIndex(new Document("actID", 1),options);

			doc.append("userName", usr)
			.append("activityName", actName)
			.append("actID", actID)
			.append("image", image)
			.append("content", content)
			.append("capacity", capacity)
			.append("registerNumber", registerNum)
			.append("comment", comment);
			collections.insertOne(doc);
			
		} catch(Exception e) {
			System.out.println(e.getClass() + " " + e.getMessage());
			return "false";
		}
		return "true";
		
	}
	
	
	public void insertActivity(String actID,String url,String text){
		MongoCollection<org.bson.Document> collections = db.getCollection("ActivityTabl");	
		mongoclient.setWriteConcern(WriteConcern.JOURNALED);
		//use unique index to check unique username and emailaddress
		options.unique(true);
		collections.createIndex(new Document("actID", 1),options);
		String json = "{\"actID\":"+actID+",\"url\":\""+url+"\",\"text\":\""+text+"\"}";
		System.out.println(json);
		Document doc = new Document().parse(new JSONObject(json).toString());
		collections.insertOne(doc);
	}
	
	public String getActivity(){
		String res = "{results:[";
		MongoCollection<org.bson.Document> collections = db.getCollection("ActivityTabl");	
		for(Document doc : collections.find().projection(fields(include("actID","url","text"), excludeId()))){
			DBObject dbo = (DBObject)JSON.parse(doc.toJson());
			res += "{\"actID\":"+dbo.get("actID")+",\"url\":\""+dbo.get("url")+"\",\"text\":\""+dbo.get("text")+"\"},";
		 }
		res = res.substring(0,res.length()-1);
		res += "]}";
		return new JSONObject(res).toString();
	}
	
	
	/*Insert News
	 * title: the title of news
	 * date: the date of news
	 * content: the content of news
	 * url: the url of news
	 * picUrl: the picture url of news*/
	public String insertNews(String title, String date, String content, String url, String picUrl){
		try {			
			MongoCollection<org.bson.Document> collections = db.getCollection("NewsTableInfo");	
			mongoclient.setWriteConcern(WriteConcern.JOURNALED);
			org.bson.Document doc = new org.bson.Document();
			
			//use unique index to check unique username and emailaddress
			options.unique(true);
			collections.createIndex(new Document("URL", 1),options);

			/*doc.append("Title", title)
			.append("Date", date)
			.append("Content", content)
			.append("URL", url)
			.append("picURL", picUrl);*/
			if(content != null && content != "" ) {
				doc = doc.parse("{Title:\""+ (title) +"\", Date:\""+(date) +"\", Content:\""
						+(content) +"\", URL:\""+(url) +"\", picURL:\""+(picUrl) + "\"}");
				collections.insertOne(doc);
			}
			
		} catch(Exception e) {
			System.out.println(e.getClass() + " " + e.getMessage());
			return "false";
		}
		return "true";
	}
	
	
	public List<JSONObject> get_news(){
		//get the news table we insert
		List<JSONObject> news = new ArrayList<JSONObject>();
		MongoCollection<org.bson.Document> c = db.getCollection("NewsTableInfo");
		System.out.println(c.count());
		MongoCursor<org.bson.Document> cursor = c.find().projection(fields(
				include("Title","Date","Content","URL","picURL"), excludeId())).iterator();
		JSONObject js = new JSONObject(); 
		while (cursor.hasNext()) {		
			try {
				js = new JSONObject(cursor.next().toJson());
				news.add(js);
				System.out.println(js);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//System.out.println(js);
		}
		
		this.close();
  
		return news;
	}
	
}

