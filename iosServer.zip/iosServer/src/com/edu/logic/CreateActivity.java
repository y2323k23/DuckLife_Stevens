package com.edu.logic;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.codec.binary.Base64;

/**
 * Servlet implementation class CreateActivity
 */
@WebServlet("/CreateActivity")
public class CreateActivity extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateActivity() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			System.out.println("The cilent has connected with server");
			int length = request.getContentLength();
	        byte[] input = new byte[length];
	        ServletInputStream sin = request.getInputStream();
	        int c, count = 0 ;
	        while ((c = sin.read(input, count, input.length-count)) != -1) {
	            count +=c;
	        }
	        sin.close();
	        String receivedString = new String(input);
	        
	       // System.out.println("The data received from client is : " + receivedString);
	        
	        //the format is :   
	        //id:id1 content:content1 image:image1
	        String[] recv = receivedString.split(" ");
	        String[] recvID = recv[0].split(":");
	        String[] recvContent = recv[1].split(":");
	        String[] recvImage = recv[2].split(":");
	        
	        String actID = recvID[1];        //get actID
	        String content = recvContent[1]; //get content
	        String image = recvImage[1];     //get image
	        System.out.println("receive id from client:"+actID+" content:"+content);
	        //String imageDataString = encodeImage(image.getBytes());
	        byte[] imageByteArray = decodeImage(image);
	        FileOutputStream imageOutFile = new FileOutputStream(
					"/Users/rq/documents/workspace/iosServer/WebContent/image/"+actID+".jpg");
	        String url = "http://localhost:8080/iosServer/image/"+actID+".jpg";
			imageOutFile.write(imageByteArray);
			imageOutFile.close();
			System.out.println("Image Successfully Manipulated!");
			
	        MongoDBHandler myfile = new MongoDBHandler();
			myfile.insertActivity(actID, url, content);
	        OutputStreamWriter out = new OutputStreamWriter(response.getOutputStream());
			out.flush();

			out.close();
		}
	public static byte[] decodeImage(String imageDataString) {
		return Base64.decodeBase64(imageDataString);
	}
	public static String encodeImage(byte[] imageByteArray) {
		return Base64.encodeBase64URLSafeString(imageByteArray);
	}
}
