package com.edu.logic;

import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.mongodb.util.JSON;

/**
 * Servlet implementation class ActivityMessage
 */
@WebServlet("/ActivityMessage")
public class ActivityMessage extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static int count = 1;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActivityMessage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("The cilent has connected with server");
		int length = request.getContentLength();
        byte[] input = new byte[length];
        ServletInputStream sin = request.getInputStream();
        int c, count = 0 ;
        while ((c = sin.read(input, count, input.length-count)) != -1) {
            count +=c;
        }
        sin.close();

        String receivedString = new String(input);
        
        System.out.println("The data received from client is : " + receivedString);
        JSONObject json = new JSONObject("{result:[{title:\""+(count++)+"\",content:\""+receivedString+"\"}]}");
        OutputStreamWriter out = new OutputStreamWriter(response.getOutputStream());
        out.write(json.toString());
        out.flush();
        out.close();
	}

}
